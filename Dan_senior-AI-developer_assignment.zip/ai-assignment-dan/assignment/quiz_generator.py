from abc import ABC, abstractmethod
from enum import Enum
from typing import List
import asyncio
import os

from dotenv import load_dotenv
from langchain.chat_models import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage

from schema import Quiz, Quizzes, Option
from prompt import (
    HISTORY_QUIZ_SYSTEM_PROMPT,
    MATH_QUIZ_SYSTEM_PROMPT,
    HISTORY_QUIZ_QUESTION_PROMPT,
    MATH_QUIZ_QUESTION_PROMPT,
)
from errors import NoEnvVaraibleException, GeneratorTypeException


# Use Enum for defining quiz generator types
class QuizGeneratorType(Enum):
    HISTORY = "history"
    MATH = "math"


class QuizGenerator(ABC):
    """
    A quiz generator to define the basic functionalities.
    """

    def __init__(self):
        # Load the openAI API KEY from personal .env file, and
        # we assume there must be at least one variable set
        if not load_dotenv():
            raise NoEnvVaraibleException
        # Initialize LangChain's OpenAI interface for GPT-3.5
        self.llm = ChatOpenAI(
            model="gpt-3.5-turbo", api_key=os.getenv("OPENAI_API_KEY")
        )
        self.option_num = None

    @abstractmethod
    def create_quiz(self, content: str, keywords: List[str]) -> Quiz:
        """
        Create a quiz including its question, and four options. Based on the given content and keywords.
        """
        pass

    @abstractmethod
    def create_quizzes(
        self, content: str, topics: List[str], num_quizzes: int
    ) -> Quizzes:
        """
        Create multiple quizzes.
        """
        pass


class HistoryQuizGenerator(QuizGenerator):
    """
    A quiz generator generating history quiz based on the given content and keywords.
    """

    def create_quiz(self, topic: str, keywords: List[str]) -> Quiz:
        """
        Create a quiz including its question, and four options. Based on the given content and keywords.
        Please use GPT-3.5 with LangChain to implement the function.
        """
        keywords_str = ", ".join(keywords)
        messages = [
            SystemMessage(content=HISTORY_QUIZ_SYSTEM_PROMPT),
            HumanMessage(content=HISTORY_QUIZ_QUESTION_PROMPT % (topic, keywords_str)),
        ]
        response = self.llm.invoke(messages)
        quiz = self.parse_generated_quiz(response.content)
        return quiz

    async def create_quizzes(
        self, topic: str, keywords: List[str], num_quizzes: int
    ) -> Quizzes:
        """
        Create multiple quizzes.
        Please use GPT-3.5 with LangChain to implement the function.
        """
        # Instead of using
        # tasks = [self.create_quiz(...) for _ in range(num_quizzes)]
        # return await asyncio.gether(*tasks)
        # I use loop event to avoid the hashable error in Quiz obj since there is a list type data inside
        loop = asyncio.get_running_loop()
        tasks = [
            loop.run_in_executor(None, self.create_quiz, topic, keywords)
            for _ in range(num_quizzes)
        ]
        # Gather tasks into a list
        quizzes = await asyncio.gather(*tasks)
        return Quizzes(quizzes=quizzes)

    def parse_generated_quiz(self, content: str) -> Quiz:
        # Split the text by sections
        parts = content.split("\n\n")

        # Step 1: Extract the question
        question = parts[0].strip()

        # Step 2: Extract options
        options_text = parts[1].strip().splitlines()
        options = {line[0]: line[3:].strip() for line in options_text}

        # Step 3: Extract the answer
        correct_answer = parts[2].split(" ")[2].split(")")[0]

        # Step 4: Extract explanation section
        # Skip "Explanation:" line
        explanation_text = parts[3].strip().splitlines()[1:]
        explanation = {}
        letters = sorted(list(options.keys()))

        for index, line in enumerate(explanation_text):
            current_letter = letters[index]
            explanation[current_letter] = line[2:].strip()

        option_pool = []
        for letter, content in options.items():
            isCorrect = True if letter == correct_answer else False
            opt = Option(
                content=content, reason=explanation[letter], isCorrect=isCorrect
            )
            option_pool.append(opt)

        return Quiz(question=question, options=option_pool)


class MathQuizGenerator(QuizGenerator):
    """
    A quiz generator generating math word quiz which involves a linear equation with two variables.
    """

    def create_quiz(self) -> Quiz:
        """
        Create a math word quiz which involves a linear equation with two variables.
        Please use GPT-3.5 with LangChain to implement the function.
        """
        messages = [
            SystemMessage(content=MATH_QUIZ_SYSTEM_PROMPT),
            HumanMessage(content=MATH_QUIZ_QUESTION_PROMPT),
        ]
        response = self.llm.invoke(messages)
        quiz = self.parse_generated_quiz(response.content)
        return quiz

    async def create_quizzes(self, num_quizzes: int) -> Quizzes:
        """
        Create multiple quizzes.
        Please use GPT-3.5 with LangChain to implement the function.
        """
        # Instead of using
        # tasks = [self.create_quiz(...) for _ in range(num_quizzes)]
        # return await asyncio.gether(*tasks)
        # I use loop event to avoid the hashable error in Quiz obj since there is a list type data inside
        loop = asyncio.get_running_loop()
        tasks = [
            loop.run_in_executor(None, self.create_quiz) for _ in range(num_quizzes)
        ]
        # Gather tasks into a list
        quizzes = await asyncio.gather(*tasks)
        return Quizzes(quizzes=quizzes)

    def parse_generated_quiz(self, content: str) -> Quiz:
        # Split the text by sections
        sections = content.split("\n\n")

        # Step 1: Extract the question
        question = sections[0].strip()

        # Step 2: Extract options
        options_text = sections[1].strip().splitlines()
        options = {line[0]: line[3:].strip() for line in options_text}

        # Step 3: Extract the answer
        correct_answer = sections[2].split(" ")[2].split(")")[0]

        # Step 4: Extract explanation section
        # Skip "Explanation:" line
        explanation_text = sections[3].strip().split("#")[1:]
        explanation = {}
        letters = sorted(list(options.keys()))

        for index, line in enumerate(explanation_text):
            current_letter = letters[index]
            explanation[current_letter] = line[4:].strip()

        option_pool = []
        for letter, content in options.items():
            isCorrect = True if letter == correct_answer else False
            opt = Option(
                content=content, reason=explanation[letter], isCorrect=isCorrect
            )
            option_pool.append(opt)

        return Quiz(question=question, options=option_pool)


class QuizGeneratorFactory:
    def create_quiz_generator(self, quiz_generator_type: str) -> QuizGenerator:
        if quiz_generator_type == QuizGeneratorType.HISTORY.value:
            return HistoryQuizGenerator()
        elif quiz_generator_type == QuizGeneratorType.MATH.value:
            return MathQuizGenerator()
        else:
            raise GeneratorTypeException
