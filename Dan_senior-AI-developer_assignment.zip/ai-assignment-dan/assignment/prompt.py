# This file is for a prompt capable of getting a fixed format result
HISTORY_QUIZ_SYSTEM_PROMPT = """
Generate a quiz with the following format:
Question: Who is credited with initiating the Protestant Reformation by nailing the 95 Theses to the door of the Wittenberg Castle Church in 1517, challenging the practices of the Roman Catholic Church?

A) John Calvin
B) Martin Luther
C) Henry VIII
D) Pope Leo X

Correct Answer: B) Martin Luther

Explanation of options:
A) John Calvin: John Calvin was a French theologian and pastor who was a prominent figure in the Protestant Reformation but he did not initiate it. He is known for his teachings on predestination and his role in establishing Calvinism.
B) Martin Luther: Martin Luther, a German monk and theologian, is credited with sparking the Protestant Reformation through his criticisms of the Catholic Church's practices, particularly indulgences. His actions led to the formation of the Lutheran Church.
C) Henry VIII: Henry VIII was the King of England who famously broke away from the Catholic Church in order to divorce his first wife, Catherine of Aragon. While his actions had significant implications for the English Reformation, he did not initiate the Protestant Reformation.
D) Pope Leo X: Pope Leo X was the Pope at the time of Martin Luther's 95 Theses but he was not the one who initiated the Protestant Reformation. He is known for his patronage of the arts and his involvement in the sale of indulgences, which Luther criticized.
"""

HISTORY_QUIZ_QUESTION_PROMPT = """Generate a multiple-choice history quiz question about %s. Keywords: %s. I need the question first, then the options, the correct answer and the explanation of every option."""

MATH_QUIZ_SYSTEM_PROMPT = """
Generate a quiz with the following format:
Question: A bakery sells muffins for $2 each and cookies for $1.50 each. If the bakery sold a total of 200 muffins and cookies combined for $320, how many of each item did they sell?

A) 100 muffins and 100 cookies
B) 120 muffins and 80 cookies
C) 80 muffins and 120 cookies
D) 150 muffins and 50 cookies

Correct Answer: B) 120 muffins and 80 cookies

Explanation of Options:#
A) If the bakery sold 100 muffins at $2 each, it would make $200 from muffins alone. Selling 100 cookies at $1.50 each would make $150. This totals $350, exceeding the given total of $320.#
B) Let x be the number of muffins and y be the number of cookies sold. The system of equations would be:
2x + 1.50y = 320
x + y = 200
Solving this system gives x = 120 and y = 80, which is the correct answer.#
C) If the bakery sold 80 muffins at $2 each, it would make $160 from muffins. Selling 120 cookies at $1.50 each would make $180. This totals $340, exceeding the given total of $320.#
D) If the bakery sold 150 muffins at $2 each, it would make $300 from muffins. Selling 50 cookies at $1.50 each would make $75. This totals $375, exceeding the given total of $320.
I want a # to be address on the last word of every Explanation of Options.
"""

MATH_QUIZ_QUESTION_PROMPT = """Generate a math word problem involving a two-variable linear system. I want a # to be address on the last word of every Explanation of Options. I need the question first, then the options, the correct answer and the explanation of every option. It's important that I want a # to be address on the last word of every Explanation of Options!!"""
