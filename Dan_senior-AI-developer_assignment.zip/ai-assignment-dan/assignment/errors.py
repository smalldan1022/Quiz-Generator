class OptionNumberException(Exception):
    """
    If the amount of the generated options is lower than a number set by a user,
    we raise this exception for reminder.
    """

    def __init__(self) -> None:
        message = "Exception occurred: The amount of the generated options is lower than the number you set"
        error_code = 401
        super().__init__(message)
        self.error_code = error_code


class NoEnvVaraibleException(Exception):
    """
    If you don't set any variable in your .env file, we raise this exception for a reminder.
    """

    def __init__(self) -> None:
        message = "Exception occurred: There is no env variable in your .env file!"
        error_code = 402
        super().__init__(message)
        self.error_code = error_code


class GeneratorTypeException(Exception):
    """
    Now we only have history and math quiz generator. This exception is for a description for users
    to know the limitation. It could be moved to some warning logging in the future.
    """

    def __init__(self, *args: object) -> None:
        message = "Exception occurred: There is no this type of quiz generator!"
        error_code = 403
        super().__init__(message)
        self.error_code = error_code
