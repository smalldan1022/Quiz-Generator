from quiz_generator import QuizGeneratorFactory
import asyncio


# Here I use the factory pattern to replace these functions. The reason is that the client can use the factory
# to create quiz generator without directly instantiating the objects, ensuring that any changes to the object
# creation process only affect the factory class.
if __name__ == "__main__":
    # set the test cases
    history_test_case_1 = {
        "topic": "Reformation",
        "keywords": ["Martin Luther", "Roman Catholic Church"],
    }
    history_test_case_2 = {
        "topic": "World War II",
        "keywords": ["J. Robert Oppenheimer"],
    }
    history_test_case_3 = {"topic": "Civil War", "keywords": ["slavery"]}

    math_test_case_1 = {}

    # Init the factory
    factory = QuizGeneratorFactory()
    history_quiz_generator = factory.create_quiz_generator(
        quiz_generator_type="history"
    )
    math_quiz_generator = factory.create_quiz_generator(quiz_generator_type="math")

    for history_test_case in [
        history_test_case_1,
        history_test_case_2,
        history_test_case_3,
    ]:
        quiz_result = history_quiz_generator.create_quiz(**history_test_case)
        print(f"\n{quiz_result}")

    quiz_result = math_quiz_generator.create_quiz(**math_test_case_1)
    print(f"\n{quiz_result}")

    # ---------------- HIGHLIGHT BONUS PART ----------------
    # Bonus point is not necessary but a plus if you finish it.
    # Bonus 1: Write an error handling mechanism to ensure that, regardless of the input,
    # the output is always in a valid format.

    # ANS: Not sure about this because I assume that an error handling mechanism means we need to throw an exception when
    # the error happens. Thus I wrote some possible exceptions in errors.py.
    # If we want to ensure that, regardless of the input, the output is always in a valid format, then it becomes a
    # pre-processing or transformation instead of an error handling mechanism.

    # Bonus 2: Implement the create_quizzes functions in the HistoryQuizGenerator and MathQuizGenerator
    # to ensure that quizzes can be generated in parallel.
    quiz_result = asyncio.run(
        history_quiz_generator.create_quizzes(**history_test_case_1, num_quizzes=2)
    )
    print(f"\n{quiz_result}")

    quiz_result = asyncio.run(
        math_quiz_generator.create_quizzes(**math_test_case_1, num_quizzes=2)
    )
    print(f"\n{quiz_result}")
